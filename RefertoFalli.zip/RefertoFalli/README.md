# Referto Falli – app Android

App Android per segnare falli personali, falli di squadra e sospensioni durante una partita di basket. Funziona anche senza internet.
I dati restano salvati sul tablet finché non premi **Nuova partita**.

## Come ottenere l'APK (una volta sola)

1. Vai su https://github.com/new, dai un nome al repository (es. `referto-falli`) e premi **Create repository**.
2. Nella pagina del repository clicca **uploading an existing file**.
3. Estrai lo zip sul computer e trascina nella pagina **tutto il contenuto** della cartella `RefertoFalli` (comprese le cartelle `.github` e `app`). Poi premi **Commit changes**.
4. Apri la scheda **Actions**: parte "Compila APK". Ci vogliono 3–5 minuti; alla fine compare il segno verde.
5. Nella pagina principale del repository, a destra, apri **Releases** e scarica `RefertoFalli.apk`.
   Puoi farlo direttamente dal tablet, entrando su GitHub con il browser.
6. Sul tablet apri il file scaricato. Android chiede di consentire l'installazione da questa fonte: autorizza e installa.

### Se la cartella `.github` non viene caricata
Su Mac le cartelle che iniziano con il punto sono nascoste e a volte non vengono trascinate. In quel caso:
**Add file → Create new file**, scrivi come nome `.github/workflows/build.yml`, incolla il contenuto del file `build.yml` dello zip e premi **Commit changes**.

## Aggiornare l'app
Sostituisci `app/src/main/assets/index.html` con la nuova versione (Add file → Upload files). GitHub ricompila da solo e pubblica una nuova Release.
Prima di installare l'aggiornamento non serve disinstallare l'app: i dati salvati restano.

## Struttura del progetto
- `app/src/main/assets/index.html`: la pagina del referto (la stessa della versione web).
- `app/src/main/java/.../MainActivity.java`: apre la pagina a schermo intero, tiene acceso lo schermo e collega i pulsanti Copia/Condividi agli strumenti di Android.
- `.github/workflows/build.yml`: istruzioni con cui GitHub compila l'APK e lo pubblica nelle Releases.
